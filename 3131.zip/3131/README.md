compile everything: javac -d . $(find VC -name "*.java")
run testfile: java VC.vc test.vc 
ass3: java VC.vc VC/Parser/t6.vc 

javac -d . $(find VC -name "*.java")
java VC.vc VC/CodeGen/gcd.vc 
java jasmin.Main VC/CodeGen/gcd.j
java VC/CodeGen/gcd

javac -d . $(find VC -name "*.java")
java VC.vc VC/CodeGen/max.vc 
java jasmin.Main VC/CodeGen/max.j
java VC/CodeGen/max

javac -d . $(find VC -name "*.java")
java VC.vc VC/CodeGen/bubble.vc 
java jasmin.Main VC/CodeGen/bubble.j
java VC/CodeGen/bubble

javac -d . $(find VC -name "*.java")
java VC.vc t5/arr.vc 
java jasmin.Main t5/arr.j
java t5/arr

javac -d . $(find VC -name "*.java")
java VC.vc t5/chain.vc 
java jasmin.Main t5/chain.j
java t5/chain

javac -d . $(find VC -name "*.java")
java VC.vc tsts/test2
java jasmin.Main tsts/test2.j
java tsts/test2

javac -d . $(find VC -name "*.java")
java VC.vc tsts/test1
java jasmin.Main tsts/test1.j
java tsts/test1

javac -d . $(find VC -name "*.java")
java VC.vc tsts/test3
java jasmin.Main tsts/test3.j
java tsts/test3

javac -d . $(find VC -name "*.java")
java VC.vc tsts/test4
java jasmin.Main tsts/test4.j
java tsts/test4


javac -d . $(find VC -name "*.java")
java VC.vc tsts/test7
java jasmin.Main tsts/test7.j
java tsts/test7


javac -d . $(find VC -name "*.java")
java VC.vc tsts/test9
java jasmin.Main tsts/test9
java tsts/test9

javac -d . $(find VC -name "*.java")             \
  && java VC.vc tsts/test38                    \
  && java jasmin.Main tsts/test38.j               \
  && java -cp . tsts.test38