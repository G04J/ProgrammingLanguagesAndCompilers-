/*
*** Emitter.java (by Navya)
*
* Sun 30 Mar 2025 14:56:56 AEDT
*
* A new frame object is created for every function just before the
* function is being translated in visitFuncDecl.
*
* All the information about the translation of a function should be
* placed in this Frame object and passed across the AST nodes as the
* 2nd argument of every visitor method in Emitter.java.
*
*/
package VC.CodeGen;
import VC.ASTs.*;
import VC.ErrorReporter;
import VC.StdEnvironment;
import java.util.ArrayList;
import java.util.Set;

public final class Emitter implements Visitor {
    private final ErrorReporter errorReporter;
    private String inputFilename;
    private String classname;
    private String outputFilename;
    private int tempArray = 0;
    private int temp = -1;

public Emitter(String inputFilename, ErrorReporter reporter) {
    this.inputFilename = inputFilename;
    errorReporter = reporter;
    
    int i = inputFilename.lastIndexOf('.');
    if (i > 0)
        classname = inputFilename.substring(0, i);
    else
        classname = inputFilename;
    
}
//************************************************************************
public final void gen(AST ast) {
    ast.visit(this, null); 
    JVM.dump(classname + ".j");
}
//************************************************************************

// Programs
public Object visitProgram(Program ast, Object o) {
    emit(JVM.CLASS, "public", classname);
    emit(JVM.SUPER, "java/lang/Object");

    emit("");

    List list = ast.FL;
    while (!list.isEmpty()) {
        DeclList dlAST = (DeclList) list;
        if (dlAST.D instanceof GlobalVarDecl) {
            GlobalVarDecl vAST = (GlobalVarDecl) dlAST.D;
            emit(JVM.STATIC_FIELD, vAST.I.spelling, VCtoJavaType(vAST.T));
        }
        list = dlAST.DL;
    }

    emit("");

    // (2) Generate <clinit> for global variables (assumed to be static)

    emit("; standard class static initializer ");
    emit(JVM.METHOD_START, "static <clinit>()V");
    emit("");

    // create a Frame for <clinit>

    Frame frame = new Frame(false);

    for (list = ast.FL; !list.isEmpty();) {
        DeclList dlAST = (DeclList) list;
        if (dlAST.D instanceof GlobalVarDecl)
            dlAST.D.visit(this, frame);
        list = dlAST.DL;
    }

    list = ast.FL;
    while (!list.isEmpty()) {
        DeclList dlAST = (DeclList) list;
        if (dlAST.D instanceof GlobalVarDecl) {
            GlobalVarDecl vAST = (GlobalVarDecl) dlAST.D;
            if (vAST.E.isEmptyExpr()) {
                if (vAST.T instanceof ArrayType) {
                    // For arrays, create a zero-length array
                    emitICONST(0);  // Default to an empty array if no initializer
                    frame.push();
                    String arrayType = VCtoJavaType(vAST.T);
                    String baseType;
                    if (arrayType.equals("[I")) {
                        baseType = "int";
                    } else if (arrayType.equals("[F")) {
                        baseType = "float";
                    } else if (arrayType.equals("[Z")) {
                        baseType = "boolean";
                    } else {
                        baseType = "int"; // Fallback
                    }
                    emit(JVM.NEWARRAY, baseType);
                } else {
                    // Scalar default init
                    if (vAST.T.equals(StdEnvironment.floatType))
                        emit(JVM.FCONST_0);
                    else
                        emit(JVM.ICONST_0);
                }
                frame.push();
                emitPUTSTATIC(VCtoJavaType(vAST.T), vAST.I.spelling);
                frame.pop();
            }
        }
        list = dlAST.DL;
    }

    emit("");
    emit("; set limits used by this method");
    emit(JVM.LIMIT, "locals", frame.getNewIndex());

    emit(JVM.LIMIT, "stack", frame.getMaximumStackSize());
    emit(JVM.RETURN);
    emit(JVM.METHOD_END, "method");

    emit("");

    // (3) Generate Java bytecode for the VC program

    emit("; standard constructor initializer ");
    emit(JVM.METHOD_START, "public <init>()V");
    emit(JVM.LIMIT, "stack 1");
    emit(JVM.LIMIT, "locals 1");
    emit(JVM.ALOAD_0);
    emit(JVM.INVOKESPECIAL, "java/lang/Object/<init>()V");
    emit(JVM.RETURN);
    emit(JVM.METHOD_END, "method");

    for (list = ast.FL; !list.isEmpty(); list = ((DeclList) list).DL) {
        Decl d = ((DeclList) list).D;
        if (!(d instanceof GlobalVarDecl)) {
            d.visit(this, frame);
        }
    }
    return null;
}

// Statements

public Object visitStmtList(StmtList ast, Object o) {
    ast.S.visit(this, o);
    ast.SL.visit(this, o);
    return null;
}

public Object visitCompoundStmt(CompoundStmt ast, Object o) {
    Frame frame = (Frame) o;

    String scopeStart = frame.getNewLabel();
    String scopeEnd = frame.getNewLabel();
    frame.scopeStart.push(scopeStart);
    frame.scopeEnd.push(scopeEnd);

    emit(scopeStart + ":");
    if (ast.parent instanceof FuncDecl) {
        if (((FuncDecl) ast.parent).I.spelling.equals("main")) {
            emit(JVM.VAR, "0 is argv [Ljava/lang/String; from " + (String) frame.scopeStart.peek() + " to " +  (String) frame.scopeEnd.peek());
            emit(JVM.VAR, "1 is vc$ L" + classname + "; from " + (String) frame.scopeStart.peek() + " to " +  (String) frame.scopeEnd.peek());
            // Generate code for the initialiser vc$ = new classname();
            emit(JVM.NEW, classname);
            emit(JVM.DUP);
            frame.push(2);
            emit("invokenonvirtual", classname + "/<init>()V");
            frame.pop();
            emit(JVM.ASTORE_1);
            frame.pop();
        } else {
            emit(JVM.VAR, "0 is this L" + classname + "; from " + (String) frame.scopeStart.peek() + " to " +  (String) frame.scopeEnd.peek());
            ((FuncDecl) ast.parent).PL.visit(this, o);
        }
    }
    ast.DL.visit(this, o);
    ast.SL.visit(this, o);
    emit(scopeEnd + ":");

    frame.scopeStart.pop();
    frame.scopeEnd.pop();
    return null;
}

public Object visitReturnStmt(ReturnStmt ast, Object o) {
    Frame frame = (Frame) o;

    // Special handling for main() which returns void
    if (frame.isMain()) {
        emit(JVM.RETURN);
        return null;
    }

    if (ast.E instanceof EmptyExpr) {
        emit(JVM.RETURN); // for void functions
        return null;
    }

    ast.E.visit(this, frame); // generate code for the return expression

    // Now handle return based on type
    Type retType = ast.E.type;
    if (retType.equals(StdEnvironment.intType) || retType.equals(StdEnvironment.booleanType)) {
        emit(JVM.IRETURN);
    } else if (retType.equals(StdEnvironment.floatType)) {
        emit(JVM.FRETURN);
    } else {
        emit(JVM.RETURN); // fallback for unexpected types
    }

    frame.pop(); // one value is returned, pop it from the stack
    return null;
}

public Object visitIfStmt(IfStmt ast, Object o) {
    Frame frame = (Frame) o;
    String label1 = frame.getNewLabel();
    String label2 = frame.getNewLabel();

    ast.E.visit(this,o);

    if(ast.E instanceof VarExpr) emitILOAD(temp);

    emit(JVM.IFEQ, label1);
    ast.S1.visit(this,o);

    emit(JVM.GOTO, label2);
    emit(label1 + ":");

    ast.S2.visit(this,o);
    emit(label2 + ":");

    return null;
}

public Object visitForStmt(ForStmt ast, Object o) {
    Frame frame = (Frame) o;
    String label1 = frame.getNewLabel();
    String label2 = frame.getNewLabel();
    String label3 = frame.getNewLabel();

    frame.conStack.push(label1);
    frame.brkStack.push(label3);

    ast.E1.visit(this,o);
    emit(JVM.GOTO, label2);
    emit(label1 + ":");

    ast.E3.visit(this,o);
    emit(label2 + ":");

    ast.E2.visit(this,o);
    emit(JVM.IFEQ, label3);

    ast.S.visit(this,o);
    emit(JVM.GOTO, label1);
    emit(label3 + ":");

    frame.conStack.pop();
    frame.brkStack.pop();

    return null;
}

public Object visitWhileStmt(WhileStmt ast, Object o) {
    Frame frame = (Frame) o;
    String label1 = frame.getNewLabel();
    String label2 = frame.getNewLabel();

    frame.conStack.push(label1);
    frame.brkStack.push(label2);

    emit(label1 + ":");
    ast.E.visit(this,o);
    if (ast.E instanceof VarExpr) emitILOAD(temp);

    emit(JVM.IFEQ, label2);
    ast.S.visit(this,o);

    emit(JVM.GOTO, label1);
    emit(label2 + ":");
    frame.conStack.pop();
    frame.brkStack.pop();

    return null;
}

public Object visitEmptyStmtList(EmptyStmtList ast, Object o) {
    return null;
}

public Object visitBreakStmt(BreakStmt ast, Object o) {
    Frame frame = (Frame) o;
    emit(JVM.GOTO, frame.brkStack.peek());
    return null;
}

public Object visitContinueStmt(ContinueStmt ast, Object o) {
    Frame frame = (Frame) o;
    emit(JVM.GOTO, frame.conStack.peek());
    return null;
}

public Object visitExprStmt(ExprStmt ast, Object o) {
    ast.E.visit(this,o);
    return null;
}

public Object visitEmptyCompStmt(EmptyCompStmt ast, Object o) {
    return null;
}

public Object visitEmptyStmt(EmptyStmt ast, Object o) {
    return null;
}

// Expressions

public Object visitCallExpr(CallExpr ast, Object o) {
    Frame frame = (Frame) o;
    String fname = ast.I.spelling;

    if (fname.startsWith("put") || fname.startsWith("get")) {
        ast.AL.visit(this, o);
        String methodSignature;

        switch (fname) {
            case "getInt":
                methodSignature = "VC/lang/System/getInt()I";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.push();
                break;
            case "putInt":
                methodSignature = "VC/lang/System/putInt(I)V";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.pop();
                break;
            case "putIntLn":
                methodSignature = "VC/lang/System/putIntLn(I)V";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.pop();
                break;
            case "getFloat":
                methodSignature = "VC/lang/System/getFloat()F";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.push();
                break;
            case "putFloat":
                methodSignature = "VC/lang/System/putFloat(F)V";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.pop();
                break;
            case "putFloatLn":
                methodSignature = "VC/lang/System/putFloatLn(F)V";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.pop();
                break;
            case "putBool":
                methodSignature = "VC/lang/System/putBool(Z)V";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.pop();
                break;
            case "putBoolLn":
                methodSignature = "VC/lang/System/putBoolLn(Z)V";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.pop();
                break;
            case "putString":
                methodSignature = "VC/lang/System/putString(Ljava/lang/String;)V";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.pop();
                break;
            case "putStringLn":
                methodSignature = "VC/lang/System/putStringLn(Ljava/lang/String;)V";
                emit(JVM.INVOKESTATIC, methodSignature);
                frame.pop();
                break;
            case "putLn":
                methodSignature = "VC/lang/System/putLn()V";
                emit(JVM.INVOKESTATIC, methodSignature);
                break;
            default:
                throw new RuntimeException("Unknown system function: " + fname);
        }

    } else {
        FuncDecl fAST = (FuncDecl) ast.I.decl;

        // Load object reference
        if (frame.isMain()) {
            emit(JVM.ALOAD_1); // vc$ instance
        } else {
            emit(JVM.ALOAD_0); // this
        }
        frame.push();  // object reference

        // Load arguments
        ast.AL.visit(this, o);

        // Build argument type string
        StringBuilder argsTypes = new StringBuilder();
        List paramL = fAST.PL;
        int argCount = 0;
        while (!paramL.isEmpty()) {
            ParaList plNode = (ParaList) paramL;
            Type paraT = plNode.P.T;
            argsTypes.append(VCtoJavaType(paraT));
            argCount++;
            paramL = plNode.PL;
        }

        String retType = VCtoJavaType(fAST.T);
        emit("invokevirtual", classname + "/" + fname + "(" + argsTypes + ")" + retType);

        frame.pop(argCount + 1);  // arguments + object reference

        if (!retType.equals("V")) {
            frame.push(); // Only push if return type is not void
        }
    }

    return null;
}

public Object visitEmptyExpr(EmptyExpr ast, Object o) {
    return null;
}

public Object visitUnaryExpr(UnaryExpr ast, Object o) {
    Frame frame = (Frame) o;
    String spelling = ast.O.spelling;

    if (spelling.equals("i!")) {
        String L1 = frame.getNewLabel();
        String L2 = frame.getNewLabel();
        ast.E.visit(this,o);
        if (ast.E instanceof VarExpr) emitILOAD(temp);
        emit(JVM.IFEQ, L1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, L2);
        emit(L1 + ":");
        emit(JVM.ICONST_1);
        emit(L2 + ":");
    }

    if (spelling.equals("i2f")) {
        ast.E.visit(this,o);
        if(ast.E instanceof VarExpr) emitILOAD(temp);
        emit(JVM.I2F);
    }

    if (spelling.equals("i-")) {
        if (ast.E instanceof IntExpr) {
            IntExpr temp = (IntExpr) ast.E;
            emitICONST(-Integer.parseInt(temp.IL.spelling));
        }
        if (ast.E instanceof FloatExpr) {
            FloatExpr temp = (FloatExpr) ast.E;
            emitFCONST(-Float.parseFloat(temp.FL.spelling));
        }
    }

    if(spelling.equals("f-")){
        if (ast.E instanceof IntExpr) {
            IntExpr temp = (IntExpr) ast.E;
            emitICONST(-Integer.parseInt(temp.IL.spelling));
        }
        if (ast.E instanceof FloatExpr) {
            FloatExpr temp = (FloatExpr) ast.E;
            emitFCONST(-Float.parseFloat(temp.FL.spelling));
        }
    }

    if (spelling.equals("f+") || spelling.equals("i+")) {
        if (ast.E instanceof IntExpr) {
            IntExpr temp = (IntExpr) ast.E;
            emitICONST(Integer.parseInt(temp.IL.spelling));
        }
        if (ast.E instanceof FloatExpr) {
            FloatExpr temp = (FloatExpr) ast.E;
            emitFCONST(Float.parseFloat(temp.FL.spelling));
        }
    }

    return null;
}

public Object visitBinaryExpr(BinaryExpr ast, Object o) {
    Frame frame = (Frame) o;
    String spelling = ast.O.spelling;

    if (spelling.equals("i&&")) {
        String L1 = frame.getNewLabel();
        String L2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if(temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        emit(JVM.IFEQ, L1);

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }
        emit(JVM.IFEQ, L1);
        emit(JVM.ICONST_1);
        emit(JVM.GOTO, L2);
        emit(L1 + ":");
        emit(JVM.ICONST_0);
        emit(L2 + ":");

    } else if (spelling.equals("i||")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        emit(JVM.IFGE, label1);

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.IFGE, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if (spelling.equals("i==")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.IF_ICMPEQ, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if (spelling.equals("i>")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.IF_ICMPGT, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if(spelling.equals("i>=")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.IF_ICMPGE, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if(spelling.equals("i<")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if(temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.IF_ICMPLT, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if (spelling.equals("i<=")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            }else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);

        }

        emit(JVM.IF_ICMPLE, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if (spelling.equals("f>")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.FCMPG);
        emit(JVM.IFGT, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if(spelling.equals("f>=")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.FCMPG);
        emit(JVM.IFGE, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if(spelling.equals("f<")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if (ast.E1 instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.FCMPL);
        emit(JVM.IFLT, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else if(spelling.equals("f<=")) {
        String label1 = frame.getNewLabel();
        String label2 = frame.getNewLabel();

        ast.E1.visit(this, o);
        if(ast.E1 instanceof VarExpr){
            VarExpr temp1 = (VarExpr) ast.E1;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        }

        emit(JVM.FCMPL);
        emit(JVM.IFLE, label1);
        emit(JVM.ICONST_0);
        emit(JVM.GOTO, label2);
        emit(label1 + ":");
        emit(JVM.ICONST_1);
        emit(label2 + ":");

    } else {
        ast.E1.visit(this, o);
        if (ast.E1 instanceof ArrayExpr) {
            ArrayExpr tempArray = (ArrayExpr) ast.E1;
            if (tempArray.type instanceof FloatType) {
                emit(JVM.FALOAD);
            }else if (tempArray.type instanceof BooleanType){
                emit(JVM.BALOAD);
            }else
                emit(JVM.IALOAD);
        } else if (ast.E1 instanceof VarExpr) {
            VarExpr tempVar = (VarExpr) ast.E1;
            if (tempVar.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        }

        ast.E2.visit(this, o);
        if (ast.E2 instanceof VarExpr) {
            VarExpr temp = (VarExpr) ast.E2;
            if (temp.type instanceof FloatType) {
                emitFLOAD(this.temp);
            } else
                emitILOAD(this.temp);
        } else if (ast.E2 instanceof ArrayExpr) {
            ArrayExpr array = (ArrayExpr) ast.E2;
            if (array.type instanceof FloatType) {
                emit(JVM.FALOAD);
            }else if (array.type instanceof BooleanType) {
                emit(JVM.BALOAD);
            } else
                emit(JVM.IALOAD);
        }

        if (spelling.equals("i+")) {
            emit(JVM.IADD);
        } else if(spelling.equals("f+")) {
            emit(JVM.FADD);
        } else if(spelling.equals("i-")) {
            emit(JVM.ISUB);
        } else if(spelling.equals("f-")) {
            emit(JVM.FSUB);
        } else if(spelling.equals("i*")) {
            emit(JVM.IMUL);
        } else if(spelling.equals("f*")) {
            emit(JVM.FMUL);
        } else if(spelling.equals("i/")) {
            emit(JVM.IDIV);
        } else if(spelling.equals("f/")) {
            emit(JVM.FDIV);
        }
    }

    return null;
}

public Object visitInitExpr(IntExpr ast, Object o) {
    Frame frame = (Frame) o;
    ast.IL.visit(this,o);
    return null;
}

public Object visitArrayExpr(ArrayExpr ast, Object o) {
    Frame frame = (Frame) o;
    ast.V.visit(this, o);
    SimpleVar eli = (SimpleVar) ast.V;

    AST decl = eli.I.decl;
    if (decl instanceof GlobalVarDecl) {
        GlobalVarDecl globalDecl = (GlobalVarDecl) decl;
        emitGETSTATIC(VCtoJavaType(globalDecl.T), globalDecl.I.spelling);
    } else
        emitALOAD(temp);
        frame.push();

    ast.E.visit(this,o);
    if (ast.E instanceof VarExpr) {
        VarExpr test = (VarExpr) ast.E;
        if(test.type instanceof IntType || test.type instanceof BooleanType) emitILOAD(temp);
        if(test.type instanceof FloatType) emitFLOAD(temp);
    }
    return null;
}

public Object visitVarExpr(VarExpr ast, Object o) {
    Frame frame = (Frame) o;
    ast.V.visit(this,o);
    frame.push();
    return null;
}

// public Object visitExprList(ExprList ast, Object o) {
//     emit(JVM.DUP);
//     emitICONST(tempArray);
//     tempArray++;

//     ast.E.visit(this,o);
//     if(ast.E.type instanceof FloatType) {
//         emit(JVM.FASTORE);
//     } else if (ast.E.type instanceof BooleanType) {
//         emit(JVM.BASTORE);
//     } else
//         emit(JVM.IASTORE);
//     ast.EL.visit(this,o);
//     return null;
// }

public Object visitAssignExpr(AssignExpr ast, Object o) {
    Frame frame = (Frame) o;
    frame.push(2);
    ast.E1.visit(this,o);
    ast.E2.visit(this,o);

    if (ast.E2 instanceof VarExpr) {
        VarExpr temp1 = (VarExpr) ast.E2;
        if(temp1.type instanceof FloatType){
            emitFLOAD(temp);
        } else
            emitILOAD(temp);
    }else if (ast.E2 instanceof ArrayExpr) {
        ArrayExpr array = (ArrayExpr) ast.E2;
        if (array.type instanceof FloatType) {
            emit(JVM.FALOAD);
        } else if (array.type instanceof BooleanType) {
            emit(JVM.BALOAD);
        } else
            emit(JVM.IALOAD);
    }

    if(ast.E1 instanceof VarExpr) {
        VarExpr tempVar = (VarExpr) ast.E1;
        Ident ident  = (Ident)tempVar.V.visit(this,o);
        AST decl = ident.decl;
        if (decl instanceof GlobalVarDecl) {
            emitPUTSTATIC(VCtoJavaType(tempVar.type), ident.spelling);
            return null;
        }

        if (tempVar.type instanceof FloatType) {
            emitFSTORE(ident);
        } else
            emitISTORE(ident);
    } else if (ast.E1 instanceof ArrayExpr) {
        ArrayExpr array = (ArrayExpr) ast.E1;
        Ident ex  = (Ident)array.V.visit(this,o);
        AST decl = ex.decl;

        if (array.type instanceof FloatType) {
            emit(JVM.FASTORE);
        } else if (array.type instanceof BooleanType) {
            emit(JVM.BASTORE);
        } else
            emit(JVM.IASTORE);
    } else
        emit(JVM.DUP);

    return null;
}

public Object visitIntExpr(IntExpr ast, Object o) {
    ast.IL.visit(this, o);
    return null;
}

public Object visitFloatExpr(FloatExpr ast, Object o) {
    ast.FL.visit(this, o);
    return null;
}

public Object visitBooleanExpr(BooleanExpr ast, Object o) {
    ast.BL.visit(this, o);
    return null;
}

public Object visitStringExpr(StringExpr ast, Object o) {
    ast.SL.visit(this, o);
    return null;
}

// Declarations

public Object visitDeclList(DeclList ast, Object o) {
    ast.D.visit(this, o);
    ast.DL.visit(this, o);
    return null;
}

public Object visitEmptyDeclList(EmptyDeclList ast, Object o) {
    return null;
}

public Object visitFuncDecl(FuncDecl ast, Object o) {

    Frame frame;

    if (ast.I.spelling.equals("main")) {

        frame = new Frame(true);

        // Assume that main has one String parameter and reserve 0 for it
        frame.getNewIndex();

        emit(JVM.METHOD_START, "public static main([Ljava/lang/String;)V");

        frame.getNewIndex();

    } else {

        frame = new Frame(false);

        frame.getNewIndex(); // reserve 0 for "this"

        String retType = VCtoJavaType(ast.T);

        StringBuilder argsTypes = new StringBuilder();
        List fpl = ast.PL;
        while (!fpl.isEmpty()) {
            ParaDecl param = ((ParaList) fpl).P;
            argsTypes.append(VCtoJavaType(param.T));
            fpl = ((ParaList) fpl).PL;
        }

        emit(JVM.METHOD_START, ast.I.spelling + "(" + argsTypes + ")" + retType);
    }

    ast.S.visit(this, frame);

    if (ast.T.equals(StdEnvironment.voidType)) {
        emit("");
        emit("; return may not be present in a VC function returning void");
        emit("; The following return inserted by the VC compiler");
        emit(JVM.RETURN);
    } else if (ast.I.spelling.equals("main")) {
        // In case VC's main does not have a return itself
        emit(JVM.RETURN);
    } else
        emit(JVM.NOP);

    emit("");
    emit("; set limits used by this method");
    emit(JVM.LIMIT, "locals", frame.getNewIndex());

    emit(JVM.LIMIT, "stack", frame.getMaximumStackSize());
    emit(".end method");

    return null;
}

public Object visitGlobalVarDecl(GlobalVarDecl ast, Object o) {
    Frame frame = (Frame) o;
    
     // Only handle array initialisation here
     if (ast.T instanceof ArrayType && !ast.E.isEmptyExpr()) {
        // This is an array with an initializer list
        ast.E.visit(this, frame);  // Generate code to create and initialize array
        emitPUTSTATIC(VCtoJavaType(ast.T), ast.I.spelling);  // Store array in static field
        frame.pop();
    }

    return null;
}

public Object visitLocalVarDecl(LocalVarDecl ast, Object o) {
    Frame frame = (Frame) o;
    ast.index = frame.getNewIndex();
    String T = VCtoJavaType(ast.T);

    emit(JVM.VAR + " " + ast.index + " is " + ast.I.spelling + " " + T + " from " + (String) frame.scopeStart.peek() + " to " +  (String) frame.scopeEnd.peek());

    frame.push();
    if (ast.T instanceof ArrayType) {
        if (!(ast.E instanceof ArrayInitExpr)) {
            ast.T.visit(this,o);
            if (ast.index >= 0 && ast.index <= 3) {
                emit(JVM.ASTORE + "_" + ast.index);
            } else
                emit(JVM.ASTORE);
        } else
            ast.T.visit(this,o);
    }

    if (!ast.E.isEmptyExpr()) {
        ast.E.visit(this, o);
        if (ast.E instanceof VarExpr) {
            VarExpr temp1 = (VarExpr) ast.E;
            if (temp1.type instanceof FloatType) {
                emitFLOAD(temp);
            } else
                emitILOAD(temp);
        } else if (ast.E instanceof ArrayExpr) {
            ArrayExpr array = (ArrayExpr) ast.E;
            if (array.type instanceof FloatType) {
                emit(JVM.FALOAD);
            } else if (array.type instanceof BooleanType) {
                emit(JVM.BALOAD);
            } else
                emit(JVM.IALOAD);
        }

        if(ast.T instanceof ArrayType){
            if (ast.index >= 0 && ast.index <= 3) {
                emit(JVM.ASTORE + "_" + ast.index);
            } else{
                emit(JVM.ASTORE, ast.index);
                emit(JVM.NOP);
            }
            frame.pop();
        } else if (ast.T.equals(StdEnvironment.floatType)) {
            // cannot call emitFSTORE(ast.I) since this I is not an
            // applied occurrence
            if (ast.index >= 0 && ast.index <= 3)
                emit(JVM.FSTORE + "_" + ast.index);
            else
                emit(JVM.FSTORE, ast.index);
            frame.pop();
        } else {
            // cannot call emitISTORE(ast.I) since this I is not an
            // applied occurrence
            if (ast.index >= 0 && ast.index <= 3)
                emit(JVM.ISTORE + "_" + ast.index);
            else
                emit(JVM.ISTORE, ast.index);
            frame.pop();
        }
    }

    return null;
}

// Parameters

public Object visitParaList(ParaList ast, Object o) {
    ast.P.visit(this, o);
    ast.PL.visit(this, o);
    return null;
}

public Object visitParaDecl(ParaDecl ast, Object o) {
    Frame frame = (Frame) o;
    ast.index = frame.getNewIndex();
    String T = VCtoJavaType(ast.T);

    emit(JVM.VAR + " " + ast.index + " is " + ast.I.spelling + " " + T + " from " + (String) frame.scopeStart.peek() + " to " +  (String) frame.scopeEnd.peek());
    return null;
}

public Object visitEmptyParaList(EmptyParaList ast, Object o) {
    return null;
}

// Arguments

public Object visitArgList(ArgList ast, Object o) {
    ast.A.visit(this, o);
    ast.AL.visit(this, o);
    return null;
}

public Object visitArg(Arg ast, Object o) {
    Frame frame = (Frame) o;
    if (ast.E instanceof VarExpr) {
        VarExpr tempVar = (VarExpr) ast.E;
        Ident ident = (Ident)tempVar.V.visit(this, o);
        AST decl = ident.decl;
        if (decl instanceof GlobalVarDecl) {
            emitGETSTATIC(VCtoJavaType(tempVar.type), ident.spelling);
            frame.push(2);
            return null;
        }
        frame.push(2);

        VarExpr tempExpr = (VarExpr) ast.E;
        if (tempExpr.type instanceof FloatType) {
            emitFLOAD(temp);
        } else
            emitILOAD(temp);
    } else {
        frame.push(2);
        ast.E.visit(this, o);
    }
    return null;
}

public Object visitEmptyArgList(EmptyArgList ast, Object o) {
    return null;
}

// Types

public Object visitIntType(IntType ast, Object o) {
    return null;
}

public Object visitFloatType(FloatType ast, Object o) {
    return null;
}

public Object visitBooleanType(BooleanType ast, Object o) {
    return null;
}

public Object visitVoidType(VoidType ast, Object o) {
    return null;
}

public Object visitErrorType(ErrorType ast, Object o) {
    return null;
}

public Object visitStringType(StringType ast, Object o) {
    return null;
}

public Object visitArrayType(ArrayType ast, Object o) {
    ast.E.visit(this,o);
    String T;

    if (ast.T.equals(StdEnvironment.booleanType)) {
        T = "boolean";
    } else if (ast.T.equals(StdEnvironment.intType)) {
        T = "int";
    } else if (ast.T.equals(StdEnvironment.floatType)) {
        T = "float";
    } else
        T = "void";

    emit(JVM.NEWARRAY, T);
    return null;
}
// Literals, Identifiers and Operators

public Object visitIdent(Ident ast, Object o) {
    return null;
}

public Object visitIntLiteral(IntLiteral ast, Object o) {
    Frame frame = (Frame) o;
    emitICONST(Integer.parseInt(ast.spelling));
    frame.push();
    return null;
}

public Object visitFloatLiteral(FloatLiteral ast, Object o) {
    Frame frame = (Frame) o;
    emitFCONST(Float.parseFloat(ast.spelling));
    frame.push();
    return null;
}

public Object visitBooleanLiteral(BooleanLiteral ast, Object o) {
    Frame frame = (Frame) o;
    emitBCONST(ast.spelling.equals("true"));
    frame.push();
    return null;
}

public Object visitStringLiteral(StringLiteral ast, Object o) {
    Frame frame = (Frame) o;
    emit(JVM.LDC, "\"" + ast.spelling + "\"");
    frame.push();
    return null;
}

public Object visitOperator(Operator ast, Object o) {
    return null;
}

// Variables

public Object visitSimpleVar(SimpleVar ast, Object o) {
    Frame frame = (Frame) o;
    AST decl = ast.I.decl;

    if (decl instanceof LocalVarDecl) {
        LocalVarDecl localDecl = (LocalVarDecl) decl;
        temp = localDecl.index;
        frame.push(localDecl.index);
    }

    if (decl instanceof ParaDecl) {
        ParaDecl paraDecl = (ParaDecl) decl;
        frame.push(paraDecl.index);
        temp = paraDecl.index;
    }

    if (decl instanceof GlobalVarDecl) {
        GlobalVarDecl globalDecl = (GlobalVarDecl) decl;
        frame.push(globalDecl.index);
    }
    return ast.I;
}

// Auxiliary methods for byte code generation

// The following method appends an instruction directly into the JVM
// Code Store. It is called by all other overloaded emit methods.

private void emit(String s) {
    JVM.append(new Instruction(s));
}

private void emit(String s1, String s2) {
    emit(s1 + " " + s2);
}

private void emit(String s1, int i) {
    emit(s1 + " " + i);
}

private void emit(String s1, float f) {
    emit(s1 + " " + f);
}

private void emit(String s1, String s2, int i) {
    emit(s1 + " " + s2 + " " + i);
}

private void emit(String s1, String s2, String s3) {
    emit(s1 + " " + s2 + " " + s3);
}

private void emitIF_ICMPCOND(String op, Frame frame) {
    String opcode;

    if (op.equals("i!="))
        opcode = JVM.IF_ICMPNE;
    else if (op.equals("i=="))
        opcode = JVM.IF_ICMPEQ;
    else if (op.equals("i<"))
        opcode = JVM.IF_ICMPLT;
    else if (op.equals("i<="))
        opcode = JVM.IF_ICMPLE;
    else if (op.equals("i>"))
        opcode = JVM.IF_ICMPGT;
    else // if (op.equals("i>="))
        opcode = JVM.IF_ICMPGE;

    String falseLabel = frame.getNewLabel();
    String nextLabel = frame.getNewLabel();

    emit(opcode, falseLabel);
    frame.pop(2);
    emit("iconst_0");
    emit("goto", nextLabel);
    emit(falseLabel + ":");
    emit(JVM.ICONST_1);
    frame.push();
    emit(nextLabel + ":");
}

private void emitFCMP(String op, Frame frame) {
    String opcode;

    if (op.equals("f!="))
        opcode = JVM.IFNE;
    else if (op.equals("f=="))
        opcode = JVM.IFEQ;
    else if (op.equals("f<"))
        opcode = JVM.IFLT;
    else if (op.equals("f<="))
        opcode = JVM.IFLE;
    else if (op.equals("f>"))
        opcode = JVM.IFGT;
    else // if (op.equals("f>="))
        opcode = JVM.IFGE;

    String falseLabel = frame.getNewLabel();
    String nextLabel = frame.getNewLabel();

    emit(JVM.FCMPG);
    frame.pop(2);
    emit(opcode, falseLabel);
    emit(JVM.ICONST_0);
    emit("goto", nextLabel);
    emit(falseLabel + ":");
    emit(JVM.ICONST_1);
    frame.push();
    emit(nextLabel + ":");

}

private void emitILOAD(int index) {
    if (index >= 0 && index <= 3)
        emit(JVM.ILOAD + "_" + index);
    else
        emit(JVM.ILOAD, index);
}

private void emitFLOAD(int index) {
    if (index >= 0 && index <= 3)
        emit(JVM.FLOAD + "_"  + index);
    else
        emit(JVM.FLOAD, index);
}

private void emitGETSTATIC(String T, String I) {
    emit(JVM.GETSTATIC, classname + "/" + I, T);
}


private void emitISTORE(Ident ast) {
    int index;
    if (ast.decl instanceof ParaDecl)
        index = ((ParaDecl) ast.decl).index;
    else
        index = ((LocalVarDecl) ast.decl).index;

    if (index >= 0 && index <= 3)
        emit(JVM.ISTORE + "_" + index);
    else
        emit(JVM.ISTORE, index);
}

private void emitALOAD(int index) {
    if (index >= 0 && index <= 3) {
        emit("aload_" + index);
    } else
        emit("aload", index);
}

private void emitFSTORE(Ident ast) {
    int index;
    if (ast.decl instanceof ParaDecl)
        index = ((ParaDecl) ast.decl).index;
    else
        index = ((LocalVarDecl) ast.decl).index;
    if (index >= 0 && index <= 3)
        emit(JVM.FSTORE + "_" + index);
    else
        emit(JVM.FSTORE, index);
}

private void emitPUTSTATIC(String T, String I) {
    emit(JVM.PUTSTATIC, classname + "/" + I, T);
}

private void emitICONST(int value) {
    if (value == -1)
        emit(JVM.ICONST_M1);
    else if (value >= 0 && value <= 5)
        emit(JVM.ICONST + "_" + value);
    else if (value >= -128 && value <= 127)
        emit(JVM.BIPUSH, value);
    else if (value >= -32768 && value <= 32767)
        emit(JVM.SIPUSH, value);
    else
        emit(JVM.LDC, value);
}

private void emitFCONST(float value) {
    if(value == 0.0)
        emit(JVM.FCONST_0);
    else if(value == 1.0)
        emit(JVM.FCONST_1);
    else if(value == 2.0)
        emit(JVM.FCONST_2);
    else
        emit(JVM.LDC, value);
}

private void emitBCONST(boolean value) {
    if (value)
        emit(JVM.ICONST_1);
    else
        emit(JVM.ICONST_0);
}

private String VCtoJavaType(Type t) {
    if (t instanceof ArrayType) {
        ArrayType arrayType = (ArrayType) t;
        if (arrayType.T instanceof IntType) {
            return "[I";
        } else if (arrayType.T instanceof VoidType) {
            return "[V";
        } else if (arrayType.T instanceof FloatType) {
            return "[F";
        } else if (arrayType.T instanceof BooleanType) {
            return "[Z";
        } else
            return "[*";
    }

    if (t.equals(StdEnvironment.booleanType))
        return "Z";
    else if (t.equals(StdEnvironment.intType))
        return "I";
    else if (t.equals(StdEnvironment.floatType))
        return "F";
    else // if (t.equals(StdEnvironment.voidType))
        return "V";
}
@Override
public Object visitEmptyArrayExprList(EmptyArrayExprList ast, Object o) {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'visitEmptyArrayExprList'");
}
@Override
public Object visitArrayInitExpr(ArrayInitExpr ast, Object o) {
    Frame frame = (Frame) o;

    int length = 0;
    List exprList = ast.IL;

    // Calculate array length
    while (!exprList.isEmpty()) {
        length++;
        exprList = ((ArrayExprList) exprList).EL;
    }

    emitICONST(length);  // Push array length onto the stack
    String elementType;
    String storeOpcode;

    if (ast.type instanceof ArrayType) {
        ArrayType arrayType = (ArrayType) ast.type;
        if (arrayType.T.equals(StdEnvironment.booleanType)) {
            elementType = "boolean";
            storeOpcode = JVM.BASTORE;
        } else if (arrayType.T.equals(StdEnvironment.intType)) {
            elementType = "int";
            storeOpcode = JVM.IASTORE;
        } else if (arrayType.T.equals(StdEnvironment.floatType)) {
            elementType = "float";
            storeOpcode = JVM.FASTORE;
        } else {
            elementType = "int";  // fallback
            storeOpcode = JVM.IASTORE;
        }
    } else {
        elementType = "int";  // fallback
        storeOpcode = JVM.IASTORE;
    }

    emit(JVM.NEWARRAY, elementType);
    frame.push();  // Push array reference

    // Now fill the array
    exprList = ast.IL;
    int index = 0;
    while (!exprList.isEmpty()) {
        ArrayExprList ael = (ArrayExprList) exprList;

        emit(JVM.DUP);   
        frame.push();
        emitICONST(index);       // Push index
        frame.push();
        ael.E.visit(this, frame);  // Push value for that index
        emit(storeOpcode);       // Store into array
        frame.pop(3);
        index++;
        exprList = ael.EL;
    }

    return null;
}

@Override
public Object visitArrayExprList(ArrayExprList ast, Object o) {
    ast.E.visit(this, o);
    ast.EL.visit(this, o);
    return null;
}

}