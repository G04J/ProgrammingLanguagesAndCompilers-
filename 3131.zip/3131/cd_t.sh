#!/bin/bash

cd VC/CodeGen || { echo "❌ Cannot enter VC/CodeGen directory"; exit 1; }

for vc_file in *.vc; do
    base_name="${vc_file%.vc}"
    expected_output="our_solution_$base_name"

    echo "=================================================="
    echo "🧪 Running test: $vc_file"

    # Go back to project root and compile .vc file
    cd ../../ || exit 1
    if ! java VC.vc "VC/CodeGen/$vc_file"; then
        echo "❌ Compilation failed for $vc_file"
        cd VC/CodeGen || exit 1
        continue
    fi

    cd VC/CodeGen || exit 1

    # Assemble .j to .class
    if ! java jasmin.Main "$base_name.j"; then
        echo "❌ Jasmin assembly failed for $base_name.j"
        continue
    fi

    # Run and capture output (no runtime error check)
    java "$base_name" > your_solution

    # Compare output with expected
    if [[ -f $expected_output ]]; then
        echo "🔍 Comparing with $expected_output"
        if diff -u "$expected_output" your_solution; then
            echo "✅ Output matches!"
        else
            echo "❌ Output differs from $expected_output"
        fi
    else
        echo "⚠️  Expected output file $expected_output not found"
    fi

    echo
done
