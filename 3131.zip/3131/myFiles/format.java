
  
//   private Expr parseVarInit(Ident identAST) throws SyntaxError {
//     //System.out.println("Entering parseVarInit");
//     if (currentToken.kind == Token.EQ) {
//         acceptOperator();
//         if (currentToken.kind == Token.LCURLY) {
//             match(Token.LCURLY);
//             List initList = new EmptyArrayExprList(null);
//             while (currentToken.kind != Token.RCURLY) {
//                 Expr exprAST = parseExpr(); 
//                 //System.out.println(currentToken);
//                 if (currentToken.kind != Token.RCURLY) {
//                     match(Token.COMMA); 
//                 }
//                 initList = new ArrayExprList(exprAST, initList, null); 
//             }
//             match(Token.RCURLY);
//             return new ArrayInitExpr(initList, null);
//         }
//         return parseExpr();
//     }      
    
//     if (currentToken.kind == Token.LBRACKET) {
//         match(Token.LBRACKET);
//         if (currentToken.kind == Token.INTLITERAL) {
//             match(Token.INTLITERAL);
//         }
//         match(Token.RBRACKET);
//     }
//     return new EmptyExpr(null);
//   }
//  //****************************************************************************
//   private List createDeclList(Decl firstDecl, Type currentType, boolean LSp) throws SyntaxError {
//       //System.out.println("Entering createDeclList");
//       java.util.List<Decl> decls = new ArrayList<>();
//       decls.add(firstDecl);
//       boolean isCom = false;
//       while (!isCom) {
//           if (currentToken.kind == Token.COMMA) {
//               match(Token.COMMA);
//               //System.out.println(currentToken);
//               Ident identAST = parseIdent();
//               Decl nextDecl;
//               if (currentToken.kind == Token.LPAREN) {
//                   nextDecl = parseFuncDecl(currentType, identAST);
//               } else {
//                   nextDecl = parseVarDecl(currentType, identAST, LSp);
//               }
//               decls.add(nextDecl);
//           } 
//           else if (currentToken.kind == Token.SEMICOLON) {
//              //System.out.println("HOLAA");
//               match(Token.SEMICOLON);
//               if (isTokenType()) {
//                   currentType = parseType();
//                   Ident identAST = parseIdent();
//                   Decl nextDecl;
//                   if (currentToken.kind == Token.LPAREN) {
//                       nextDecl = parseFuncDecl(currentType, identAST);
//                   } else {
//                       nextDecl = parseVarDecl(currentType, identAST, LSp);
//                   }
//                   decls.add(nextDecl);
//               } else {
//                   isCom = true;
//               }
//           } 
//           else if (isTokenType()) {
//             //System.out.println("hii");
//               currentType = parseType();
//               Ident identAST = parseIdent();
//               Decl nextDecl;
//               if (currentToken.kind == Token.LPAREN) {
//                   nextDecl = parseFuncDecl(currentType, identAST);
//               } else {
//                   nextDecl = parseVarDecl(currentType, identAST, LSp);
//               }
//               decls.add(nextDecl);
//           } 
//           else if (currentToken.kind == Token.EOF) {
//               isCom = true;
//           } 
//           else {
//               //System.out.println("oi");
//               isCom = true;
//           }
//       }
//       List result = new EmptyDeclList(null);
//       for (int i = decls.size() - 1; i >= 0; i--) {
//           result = new DeclList(decls.get(i), result, null);
//       }
//       return result;
//   }

//   //****************************************************************************
  
//   // Iterative version of parseStmtList replacing the recursive version.
//   private List parseStmtList() throws SyntaxError {
//     java.util.List<Stmt> stmtArray = new ArrayList<>();
//     while (currentToken.kind != Token.RCURLY) {
//       Stmt stmt = parseStmt();
//       stmtArray.add(stmt);
//     }
//     List result = new EmptyStmtList(null);
//     for (int i = stmtArray.size() - 1; i >= 0; i--) {
//       result = new StmtList(stmtArray.get(i), result, null);
//     }
//     return result;
//   }

//   private Stmt parseExprStmt() throws SyntaxError {
//     if (currentToken.kind != Token.SEMICOLON) {
//       Expr expr = parseExpr();
//       match(Token.SEMICOLON);
//       return new ExprStmt(expr, null);
//     } else {
//       match(Token.SEMICOLON);
//       return new ExprStmt(new EmptyExpr(null), null);
//     }
//   }
//   //****************************************************************************
//   private List parseArgs() throws SyntaxError {
//     List argList = new EmptyArgList(null);
//     match(Token.LPAREN);
//     if (currentToken.kind == Token.RPAREN) {
//       return new EmptyArgList(null);
//     }
//     Arg arg = parseArg();
//     argList = new ArgList(arg, argList, null);
//     while (currentToken.kind == Token.COMMA) {
//       accept();
//       arg = parseArg();
//       argList = new ArgList(arg, argList, null);
//     }
//     return argList;
//   }

// **************************************************************************

//   //****************************************************************************
//   private Expr parseAssignmentExpr() throws SyntaxError {
//     Expr LExpr = parseLogicalOrExpr();
//     while (currentToken.kind == Token.EQ) {
//       //System.out.println(currentToken);
//       Operator operator = acceptOperator();
//       Expr RExpr = parseLogicalOrExpr();
//       LExpr = new AssignExpr(LExpr, RExpr, null);
//     }
//     return LExpr;
//   }
//   //****************************************************************************
//   private Expr parseLogicalOrExpr() throws SyntaxError {
//     Expr LExpr = parseLogicalAndExpr();
//     while (currentToken.kind == Token.OROR) {
//       //System.out.println(currentToken);
//       Operator operator = acceptOperator();
//       Expr RExpr = parseLogicalAndExpr();
//       LExpr = new BinaryExpr(LExpr, operator, RExpr, null);
//     }
//     return LExpr;
//   }
//   //****************************************************************************
//   private Expr parseLogicalAndExpr() throws SyntaxError {
//     Expr LExpr = parseEqualityExpr();
//     while (currentToken.kind == Token.ANDAND) {
//       //System.out.println(currentToken);
//       Operator operator = acceptOperator();
//       Expr RExpr = parseEqualityExpr();
//       LExpr = new BinaryExpr(LExpr, operator, RExpr, null);
//     }
//     return LExpr;
//   }
//   //****************************************************************************
//   private Expr parseEqualityExpr() throws SyntaxError {
//     Expr LExpr = parseRelationalExpr();
//     while (currentToken.kind == Token.EQEQ || currentToken.kind == Token.NOTEQ) {
//       //System.out.println(currentToken);
//       Operator operator = acceptOperator();
//       Expr RExpr = parseRelationalExpr();
//       LExpr = new BinaryExpr(LExpr, operator, RExpr, null);
//     }
//     return LExpr;
//   }
//   //****************************************************************************
//   private Expr parseRelationalExpr() throws SyntaxError {
//     while (isRelationalOperator()) {
//       Operator operator = acceptOperator();
//       Expr RExpr = parseAdditiveExpr();
//       return new BinaryExpr(LExpr, operator, RExpr, null);
//     }
//     return parseAdditiveExpr();
//   }
//   //****************************************************************************
//   private Expr parseAdditiveExpr() throws SyntaxError {
//     Expr LExpr = parseMultiplicativeExpr();
//     while (currentToken.kind == Token.PLUS || currentToken.kind == Token.MINUS) {
//       Operator operator = acceptOperator();
//       Expr RExpr = parseMultiplicativeExpr();
//       LExpr = new BinaryExpr(LExpr, operator, RExpr, null);
//     }
//     return LExpr;
//   }
//   //****************************************************************************
//   private Expr parseMultiplicativeExpr() throws SyntaxError {
//     Expr LExpr = parseUnaryExpr();
//     while (currentToken.kind == Token.MULT || currentToken.kind == Token.DIV) {
//       Operator operator = acceptOperator();
//       Expr RExpr = parseUnaryExpr();
//       LExpr = new BinaryExpr(LExpr, operator, RExpr, null);
//     }
//     return LExpr;
//   }
//   //****************************************************************************
//   private Expr parseUnaryExpr() throws SyntaxError {
//     if(isUnaryOperator()) {
//       Operator operator = acceptOperator();
//       Expr operand = parseUnaryExpr();
//       return new UnaryExpr(operator, operand, null);
//     } 
//     return parsePrimaryExpr();
//   }
