#!/bin/bash

# Redirect all output (stdout + stderr) to a log file AND the console
exec > >(tee report) 2>&1

echo "Compiling VC..."
javac VC/vc.java VC/Checker/Checker.java 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Compilation failed. Please check Checker.java and dependencies."
    exit 1
fi

mkdir -p tmp_output

GREEN="\033[0;32m"
RED="\033[0;31m"
NC="\033[0m"

pass_count=0
fail_count=0

normalize_output() {
    # 1. Remove positions and identifier names
    # 2. Keep only the error type message
    # 3. Ignore order by sorting lines
    # 4. Remove blank lines
    sed -E 's/[0-9]+\([0-9]+\)\.\.[0-9]+\([0-9]+\): \*([0-9]+):/\*\1:/g' "$1" \
        | sed -E 's/: [a-zA-Z_][a-zA-Z_0-9]*$//g' \
        | grep -v '^$' \
        | sort
}

for i in $(seq 1 87); do
    test_file="ASS-TESTS/test$i"
    expected_file="ASS-RESULTS/result$i"
    raw_output="tmp_output/raw_out$i.txt"
    trimmed_output="tmp_output/out$i.txt"

    if [ ! -f "$test_file" ] || [ ! -f "$expected_file" ]; then
        echo -e "${RED}❌ test$i: Missing input or expected result${NC}"
        continue
    fi

    java VC.vc "$test_file" > "$raw_output" 2>&1

    # Trim up to and including the final pass/fail line
    awk '/Compilation was (un)?successful\./ { print; exit } { print }' "$raw_output" > "$trimmed_output"
    expected_trimmed="tmp_output/expected_trimmed$i.txt"
    awk '/Compilation was (un)?successful\./ { print; exit } { print }' "$expected_file" > "$expected_trimmed"

    # Normalize and compare
    norm_actual="tmp_output/norm_out$i.txt"
    norm_expected="tmp_output/norm_expected$i.txt"
    normalize_output "$trimmed_output" > "$norm_actual"
    normalize_output "$expected_trimmed" > "$norm_expected"

    if diff -q "$norm_expected" "$norm_actual" > /dev/null; then
        echo -e "${GREEN}✅ test$i: PASSED${NC}"
        ((pass_count++))
    else
        echo -e "${RED}❌ test$i: FAILED${NC}"
        echo "---- diff (expected vs actual) ----"
        diff -u "$norm_expected" "$norm_actual"
        echo "-----------------------------------"
        ((fail_count++))
    fi
done

# Summary
echo -e "\n=============================="
echo -e "Total Tests: 87"
echo -e "${GREEN}Passed: $pass_count${NC}"
echo -e "${RED}Failed: $fail_count${NC}"
echo -e "=============================="
