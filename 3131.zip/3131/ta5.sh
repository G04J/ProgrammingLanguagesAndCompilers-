#!/bin/bash

# COLORS for pretty output
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# Directories
TEST_DIR="tsts"
RESULT_DIR="res"

# Count of passed tests
pass_count=0

# 1) Rebuild your VC‐compiler once up front
echo "Rebuilding VC compiler…"
javac -d . $(find VC -name "*.java")
if [ $? -ne 0 ]; then
  echo -e "${RED}Failed to compile VC compiler. Aborting.${NC}"
  exit 1
fi

echo "Running 55 tests…"

for i in {1..55}; do
  VC_FILE="$TEST_DIR/test${i}"
  J_FILE="$TEST_DIR/test${i}.j"
  CLASS_FILE="$TEST_DIR/test${i}.class"
  EXP_FILE="$RESULT_DIR/result${i}"

  echo "-----------------------------"
  echo "Test $i"

  # 2) Generate .j from VC source
  if [ ! -f "$VC_FILE" ]; then
    echo -e "${RED}MISSING VC FILE:${NC} $VC_FILE"
    continue
  fi

  java VC.vc "$VC_FILE"
  if [ $? -ne 0 ] || [ ! -f "$J_FILE" ]; then
    echo -e "${RED}Failed to generate Jasmin (.j) for test $i.${NC}"
    continue
  fi

  # 3) Remove any stale .class so Jasmin will re-create it
  rm -f "$CLASS_FILE"

  # 4) Assemble .j → .class
  java jasmin.Main "$J_FILE" >/dev/null 2>&1
  if [ $? -ne 0 ] || [ ! -f "$CLASS_FILE" ]; then
    echo -e "${RED}Jasmin assembly error for test $i.${NC}"
    continue
  fi

  # 5) Run the newly generated class
  java -cp . "tsts.test${i}" > output.txt 2>&1
  if [ $? -ne 0 ]; then
    echo -e "${RED}Runtime error in test $i.${NC}"
    continue
  fi

  # 6) Extract only the “=== The output of the test program ===” section
  awk '/=== The output of the test program ===/{found=1;next} found' "$EXP_FILE" > expected.txt

  # 7) Compare
  if diff -w -B expected.txt output.txt >/dev/null; then
    echo -e "Test $i: ${GREEN}PASS${NC}"
    pass_count=$((pass_count+1))
  else
    echo -e "Test $i: ${RED}FAIL${NC}"
    echo "Expected:"
    cat expected.txt
    echo "Got:"
    cat output.txt
  fi

  # cleanup
  rm -f output.txt expected.txt
done

echo ""
echo -e "Tests passed: ${GREEN}${pass_count}/55${NC}"
