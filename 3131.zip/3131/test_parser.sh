#!/bin/bash

# Colors for output formatting
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Directory containing test cases
TEST_DIR="./VC/Parser"

# Success message to look for
SUCCESS_MSG="Compilation was successful."

# Counter for statistics
total_tests=0
passed_tests=0
failed_tests=0

# Create a results directory if it doesn't exist
mkdir -p test_results

echo "======= Testing the VC Parser ======="
echo "Running tests from t1.vc to t46.vc..."
echo

# Loop through test cases from t1.vc to t46.vc
for i in $(seq 1 46); do
    test_file="${TEST_DIR}/t${i}.vc"
    
    # Check if the file exists
    if [ -f "$test_file" ]; then
        total_tests=$((total_tests + 1))
        
        echo -n "Testing t${i}.vc: "
        
        # Run the parser and capture output
        output=$(java VC.vc "$test_file" 2>&1)
        
        # Save output to a file for reference
        echo "$output" > "test_results/t${i}.output"
        
        # Check if the output contains the success message
        if echo "$output" | grep -q "$SUCCESS_MSG"; then
            echo -e "${GREEN}PASS${NC}"
            passed_tests=$((passed_tests + 1))
        else
            echo -e "${RED}FAIL${NC}"
            failed_tests=$((failed_tests + 1))
            echo "  Output saved to test_results/t${i}.output"
        fi
    else
        echo "Warning: Test file t${i}.vc not found"
    fi
done

# Print summary
echo
echo "======= Test Summary ======="
echo "Total tests: $total_tests"
echo -e "${GREEN}Passed: $passed_tests${NC}"
echo -e "${RED}Failed: $failed_tests${NC}"
echo "Success rate: $(echo "scale=2; $passed_tests * 100 / $total_tests" | bc)%"
echo

# Check if all tests passed
if [ $passed_tests -eq $total_tests ]; then
    echo -e "${GREEN}All tests passed successfully!${NC}"
else
    echo -e "${RED}Some tests failed. Check test_results/ directory for details.${NC}"
fi